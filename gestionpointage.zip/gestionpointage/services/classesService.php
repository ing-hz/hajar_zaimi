<?php

include_once 'beans/classes.php';
include_once 'connexion/Connexion.php';
include_once 'dao/IDao.php';
class classesService implements IDao {

    private $connexion;

    function __construct() {
        $this->connexion = new Connexion();
    }


    public function create($o) {
        $query = "INSERT INTO classes VALUES (NULL,?,?)";
        $req = $this->connexion->getConnexion()->prepare($query);
        $req->execute(array($o->getCode(),$o->getIdFiliere() )) or die('Error');

    }

    public function delete($id) {
        $query = "DELETE FROM classes WHERE id = ?";
        $req = $this->connexion->getConnexion()->prepare($query);
        $req->execute(array($id)) or die("erreur delete");
    }

    public function findAll() {
        $query = "select * from classes";
        $req = $this->connexion->getConnexion()->query($query);
        $f= $req->fetchAll(PDO::FETCH_OBJ);
        return $f;
    }


    public function findById($id) {
        $query = "select * from classes where id =?";
        $req = $this->connexion->getConnexion()->prepare($query);
        $req->execute(array($id));
        $res=$req->fetch(PDO::FETCH_OBJ);
        $classes = new classes($res->id,$res->code, $res->IdFiliere);
        return $classes;
    }

     public function findByIdApi($id) {
        $query = "select * from classes where id =?";
        $req = $this->connexion->getConnexion()->prepare($query);
        $req->execute(array($id));
        $res=$req->fetch(PDO::FETCH_OBJ);
        return $res;
    }

    public function update($o) {
        $query = "UPDATE classes SET IdFiliere = ?,code=? where id = ?";
        $req = $this->connexion->getConnexion()->prepare($query);
        $req->execute(array($o->getIdFiliere(),$o->getCode(), $o->getId())) or die('Error');
    }
        public function findFiliere() {
        $query = "select classes.id,classes.code as nom,filiere.code from Classes,filiere where filiere.id=classes.IdFiliere ";
        $req = $this->connexion->getConnexion()->query($query);
        $f = $req->fetchAll(PDO::FETCH_OBJ);
        return $f;
    }

    public function findFiliere1($code_filiere) {
        $query = "select classes.id,classes.code as nom,filiere.code from Classes,filiere where filiere.id=classes.IdFiliere and classes.IdFiliere=?";
        $req = $this->connexion->getConnexion()->prepare($query);
        $req->execute(array($code_filiere));
        $f = $req->fetchAll(PDO::FETCH_OBJ);
        return $f;
    }

    public function count() {
        $query = "select count(classes.IdFiliere) as nbr,filiere.code as nom from Classes,filiere where filiere.id=classes.IdFiliere group by nom";
        $req = $this->connexion->getConnexion()->query($query);
        $f = $req->fetchAll(PDO::FETCH_OBJ);
        return $f;
    }
    
    }

    
