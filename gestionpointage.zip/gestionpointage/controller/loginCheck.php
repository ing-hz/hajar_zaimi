<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
chdir('..');
include_once 'beans/Etudiant.php';
include_once 'services/EtudiantService.php';
extract($_POST);

$es = new EtudiantService();
$cin = $es->findByEmail($email);
if ($cin != -1) {
    $etudiant= $es->findById($cin);
    if ($etudiant->getPassword() == md5($password)) {
        header('Content-type: application/json');
        echo json_encode(array("cin"=>$etudiant->getCin(),"nom"=>$etudiant->getNom(),"prenom"=>$etudiant->getPrenom()
                ,"password"=>$etudiant->getPassword(),"email"=>$etudiant->getEmail(),"photo"=>$etudiant->getPhoto()
                ,"role"=>$etudiant->getRole()));
    } else
        echo 0;
}else {
    echo 0;
}
