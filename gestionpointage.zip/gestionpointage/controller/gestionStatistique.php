<?php

chdir('..');
include_once 'services/classesService.php';
extract($_POST);

$fs = new classesService();

header('Content-type: application/json');
echo json_encode($fs->count());
