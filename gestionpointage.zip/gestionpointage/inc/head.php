<meta charset="UTF-8">
<title>Pointage</title>
<script src="script/jquery-3.3.1.min.js" type="text/javascript"></script>
<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>
<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="style/main.css" rel="stylesheet" type="text/css"/>
<script src="script/bootstrap.min.js" type="text/javascript"></script>
